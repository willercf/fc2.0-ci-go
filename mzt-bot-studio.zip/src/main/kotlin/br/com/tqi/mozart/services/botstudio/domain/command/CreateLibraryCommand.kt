package br.com.tqi.mozart.services.botstudio.domain.command

import org.axonframework.modelling.command.TargetAggregateIdentifier

data class CreateLibraryCommand (
        @TargetAggregateIdentifier
        val id: String,
        val name: String
)
