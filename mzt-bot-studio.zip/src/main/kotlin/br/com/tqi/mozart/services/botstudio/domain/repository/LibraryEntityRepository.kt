package br.com.tqi.mozart.services.botstudio.domain.repository

import org.springframework.data.mongodb.repository.MongoRepository

interface LibraryEntityRepository : MongoRepository<LibraryEntity, String> {

    fun findOneById(id: String): LibraryEntity
    
    fun findByName(name: String): MutableList<LibraryEntity>
}