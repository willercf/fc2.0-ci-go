package br.com.tqi.mozart.services.botstudio.domain.aggregate

import org.axonframework.modelling.command.AggregateLifecycle.*

import br.com.tqi.mozart.services.botstudio.domain.command.CreateLibraryCommand
import br.com.tqi.mozart.services.botstudio.domain.command.UpdateLibraryCommand
import br.com.tqi.mozart.services.botstudio.domain.event.LibraryCreatedEvent
import br.com.tqi.mozart.services.botstudio.domain.event.LibraryUpdatedEvent
import org.axonframework.commandhandling.CommandHandler
import org.axonframework.eventsourcing.EventSourcingHandler
import org.axonframework.modelling.command.AggregateIdentifier
import org.axonframework.spring.stereotype.Aggregate
import org.springframework.util.Assert
import java.time.Instant

@Aggregate
class Library {

    @AggregateIdentifier
    lateinit var id: String
    lateinit var name: String
    lateinit var createdAt: Instant
    lateinit var updatedAt: Instant
    lateinit var isbnBooks: MutableList<String>

    constructor()

    @CommandHandler
    constructor(cmd: CreateLibraryCommand) {

        Assert.notNull(cmd.id, "Id should not be null")
        Assert.notNull(cmd.name, "Name should not be null")
        apply(LibraryCreatedEvent(cmd.id, cmd.name, Instant.now(), Instant.now()))
    }

    @CommandHandler
    fun updateLibrary(cmd: UpdateLibraryCommand) {

        Assert.notNull(cmd.id, "Id should not be null")
        Assert.notNull(cmd.name, "Name should not be null")
        apply(LibraryUpdatedEvent(cmd.id, cmd.name, Instant.now()))
    }

    @EventSourcingHandler
    private fun create(event: LibraryCreatedEvent) {
        id = event.id
        name = event.name
        createdAt = event.createdAt
        updatedAt = event.updatedAt
        isbnBooks = mutableListOf()
    }

    @EventSourcingHandler
    private fun update(event: LibraryUpdatedEvent) {
        id = event.id
        name = event.name
        updatedAt = event.updatedAt
        isbnBooks = mutableListOf()
    }
}
