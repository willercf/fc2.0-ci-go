package br.com.tqi.mozart.services.botstudio.domain.event

import java.time.Instant

class LibraryUpdatedEvent(
        val id: String,
        val name: String,
        val updatedAt: Instant
)
