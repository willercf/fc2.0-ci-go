package br.com.tqi.mozart.services.botstudio

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.boot.runApplication
import org.springframework.cache.annotation.EnableCaching
import org.springframework.scheduling.annotation.EnableAsync
import java.util.stream.Collectors
import java.util.stream.Stream

@SpringBootApplication
@EnableConfigurationProperties
@EnableAsync
class BotStudioApplication

val LOGGER: Logger = LoggerFactory.getLogger(BotStudioApplication::class.java)

fun main(args: Array<String>) {
    runApplication<BotStudioApplication>(*args)
    LOGGER.info(Stream.of("",
            "---------------------------------------",
            " Bot Studio - Started ",
            "---------------------------------------"
    ).collect(Collectors.joining("\n")));
}
