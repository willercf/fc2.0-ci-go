package br.com.tqi.mozart.services.botstudio.domain.controller

import br.com.tqi.mozart.services.botstudio.domain.controller.request.CreateLibraryRequest
import br.com.tqi.mozart.services.botstudio.domain.projection.query.LibraryQueryBean
import br.com.tqi.mozart.services.botstudio.domain.service.LibraryCommandService
import br.com.tqi.mozart.services.botstudio.domain.service.LibraryQueryService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus.CREATED
import org.springframework.http.MediaType.APPLICATION_JSON_VALUE
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping(value = ["/v1/libraries"], consumes = [APPLICATION_JSON_VALUE], produces = [APPLICATION_JSON_VALUE])
class LibraryController {

    var commandService: LibraryCommandService
    var queryService: LibraryQueryService

    @Autowired
    constructor(commandService: LibraryCommandService, queryService: LibraryQueryService) {
        this.commandService = commandService
        this.queryService = queryService
    }

    @PostMapping
    @ResponseStatus(CREATED)
    fun addLibrary(@RequestBody request: CreateLibraryRequest): String = commandService.addBook(request)

    @PutMapping("/{id}")
    fun updateLibrary(@PathVariable id: String, @RequestBody library: CreateLibraryRequest) = commandService.updateLibrary(id, library)

    @GetMapping
    fun getAll(): List<LibraryQueryBean> = queryService.getAll()

    @GetMapping(value = ["/{name}"])
    fun findByName(@PathVariable name: String): List<LibraryQueryBean> = queryService.findByName(CreateLibraryRequest(name))
}