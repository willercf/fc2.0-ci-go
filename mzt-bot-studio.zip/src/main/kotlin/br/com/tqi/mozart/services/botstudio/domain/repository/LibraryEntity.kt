package br.com.tqi.mozart.services.botstudio.domain.repository

import br.com.tqi.mozart.services.botstudio.domain.event.LibraryCreatedEvent
import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.index.Indexed
import org.springframework.data.mongodb.core.mapping.Document
import java.time.Instant

@Document(value = "library")
data class LibraryEntity(
        @Id
        val id: String,
        @Indexed
        var name: String,
        @Indexed
        var createdAt: Instant,
        @Indexed
        var updatedAt: Instant
) {
    constructor(event: LibraryCreatedEvent) : this(event.id, event.name, event.createdAt, event.updatedAt)
}
