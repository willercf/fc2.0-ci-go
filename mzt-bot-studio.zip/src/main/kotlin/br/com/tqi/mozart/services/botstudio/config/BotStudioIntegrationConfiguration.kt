package br.com.tqi.mozart.services.botstudio.config

import br.com.tqi.mozart.libs.baseapplication.config.BaseIntegrationConfiguration
import org.springframework.context.annotation.Configuration

@Configuration
class BotStudioIntegrationConfiguration : BaseIntegrationConfiguration() {

}