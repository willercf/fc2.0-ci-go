package br.com.tqi.mozart.services.botstudio.domain.listener

import br.com.tqi.mozart.services.botstudio.domain.event.LibraryCreatedEvent
import br.com.tqi.mozart.services.botstudio.domain.event.LibraryUpdatedEvent
import br.com.tqi.mozart.services.botstudio.domain.repository.LibraryEntity
import br.com.tqi.mozart.services.botstudio.domain.repository.LibraryEntityRepository
import org.axonframework.eventhandling.EventHandler
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component
class LibraryListener {

    var repository: LibraryEntityRepository

    @Autowired
    constructor(entityRepository: LibraryEntityRepository) {
        this.repository = entityRepository
    }

    @EventHandler
    fun on(event: LibraryCreatedEvent) {
        println("===========================")
        println("id: ${event.id}")
        println("name: ${event.name}")
        println("===========================")

        val library = LibraryEntity(event)
        repository.save(library)
    }

    @EventHandler
    fun on(event: LibraryUpdatedEvent) {
        println("===========================")
        println("id: ${event.id}")
        println("name: ${event.name}")
        println("===========================")

        var library = repository.findById(event.id).orElseGet(null) ?: throw Exception()
        library.name = event.name
        library.updatedAt = event.updatedAt
        repository.save(library)
    }
}
