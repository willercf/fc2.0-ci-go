package br.com.tqi.mozart.services.botstudio.domain.controller.request

data class CreateLibraryRequest(
        val name: String
) {
    constructor() : this("")
}
