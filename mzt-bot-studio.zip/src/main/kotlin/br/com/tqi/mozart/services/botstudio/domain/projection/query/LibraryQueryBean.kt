package br.com.tqi.mozart.services.botstudio.domain.projection.query

data class LibraryQueryBean(
        val id: String,
        val name: String
) {
    constructor() : this("", "")
}
