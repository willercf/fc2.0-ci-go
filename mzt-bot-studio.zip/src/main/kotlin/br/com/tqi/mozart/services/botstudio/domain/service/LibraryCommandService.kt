package br.com.tqi.mozart.services.botstudio.domain.service

import br.com.tqi.mozart.services.botstudio.domain.command.CreateLibraryCommand
import br.com.tqi.mozart.services.botstudio.domain.command.UpdateLibraryCommand
import br.com.tqi.mozart.services.botstudio.domain.controller.request.CreateLibraryRequest
import org.axonframework.commandhandling.gateway.CommandGateway
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*

@Service
class LibraryCommandService {

    var commandGateway: CommandGateway


    @Autowired
    constructor(commandGateway: CommandGateway) {
        this.commandGateway = commandGateway
    }

    fun addBook(request: CreateLibraryRequest): String {
        val id = UUID.randomUUID().toString()
        commandGateway.sendAndWait<CreateLibraryCommand>(CreateLibraryCommand(id, request.name))
        return id;
    }

    fun updateLibrary(id: String, library: CreateLibraryRequest) {
        commandGateway.sendAndWait<UpdateLibraryCommand>(UpdateLibraryCommand(id, library.name))
    }
}
