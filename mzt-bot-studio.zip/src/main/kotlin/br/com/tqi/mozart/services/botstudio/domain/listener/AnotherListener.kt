package br.com.tqi.mozart.services.botstudio.domain.listener

import br.com.tqi.mozart.services.botstudio.domain.event.LibraryCreatedEvent
import br.com.tqi.mozart.services.botstudio.domain.event.LibraryUpdatedEvent
import org.axonframework.eventhandling.EventHandler
import org.springframework.stereotype.Component

@Component
class AnotherListener {

    @EventHandler
    fun addBook(event: LibraryCreatedEvent) {
        println("===========================")
        println("Hi... I'm another service listening libraries")
        println("id: ${event.id}")
        println("name: ${event.name}")
        println("===========================")
    }

    @EventHandler
    fun on(event: LibraryUpdatedEvent) {
        println("===========================")
        println("Hi... I'm another service listening libraries update")
        println("id: ${event.id}")
        println("name: ${event.name}")
        println("===========================")

    }
}
