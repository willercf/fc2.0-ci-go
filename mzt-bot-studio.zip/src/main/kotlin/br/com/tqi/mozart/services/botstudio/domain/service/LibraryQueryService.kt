package br.com.tqi.mozart.services.botstudio.domain.service

import br.com.tqi.mozart.services.botstudio.domain.controller.request.CreateLibraryRequest
import br.com.tqi.mozart.services.botstudio.domain.projection.query.LibraryQueryBean
import br.com.tqi.mozart.services.botstudio.domain.projection.LibraryProjector
import org.axonframework.queryhandling.QueryGateway
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class LibraryQueryService {

    var queryGateway: QueryGateway
    var projection: LibraryProjector

    @Autowired
    constructor(queryGateway: QueryGateway, projection: LibraryProjector) {
        this.queryGateway = queryGateway
        this.projection = projection
    }


    /*
    fun getAll(): List<LibraryQueryBean> =
            queryGateway.query("getAllLibraries", ResponseTypes.multipleInstancesOf(LibraryQueryBean::class.java)).get()

    fun findByName(library: LibraryBean): List<LibraryQueryBean> =
            queryGateway.query(library, ResponseTypes.multipleInstancesOf(LibraryQueryBean::class.java)).get()
    */

    fun getAll(): List<LibraryQueryBean> = projection.getAll()

    fun findByName(library: CreateLibraryRequest): List<LibraryQueryBean> = projection.findByName(library)
}