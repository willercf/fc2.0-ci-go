package br.com.tqi.mozart.services.botstudio.domain.projection

import br.com.tqi.mozart.services.botstudio.domain.controller.request.CreateLibraryRequest
import br.com.tqi.mozart.services.botstudio.domain.projection.query.LibraryQueryBean
import br.com.tqi.mozart.services.botstudio.domain.repository.LibraryEntityRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component
import java.util.stream.Collectors

@Component
class LibraryProjector {

    var repository: LibraryEntityRepository

    @Autowired
    constructor(repository: LibraryEntityRepository) {
        this.repository = repository
    }

    //@QueryHandler(queryName = "getAllLibraries")
    fun getAll(): List<LibraryQueryBean> {
        return repository.findAll()
                .stream()
                .map { LibraryQueryBean(it.id, it.name) }
                .collect(Collectors.toList())
    }

    //@QueryHandler
    fun findByName(library: CreateLibraryRequest): List<LibraryQueryBean> {
        return repository.findByName(library.name)
                .stream()
                .map { LibraryQueryBean(it.id, it.name) }
                .collect(Collectors.toList())
    }
}