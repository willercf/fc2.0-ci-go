package br.com.tqi.mozart.services.botstudio.config

//import com.github.cloudyrock.mongock.SpringBootMongock
//import com.github.cloudyrock.mongock.SpringBootMongockBuilder
//import com.github.cloudyrock.mongock.decorator.impl.MongockTemplate
import org.springframework.boot.autoconfigure.domain.EntityScan
import org.springframework.context.annotation.ComponentScan
import org.springframework.context.annotation.Configuration
import org.springframework.data.jpa.repository.config.EnableJpaRepositories
import org.springframework.data.mongodb.config.EnableMongoAuditing
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories

@Configuration
@EntityScan(basePackages = ["br.com.tqi.mozart", "org.axonframework.eventhandling"])
@ComponentScan(value = ["br.com.tqi.mozart"])
@EnableMongoRepositories(basePackages = ["br.com.tqi.mozart"])
@EnableMongoAuditing
@EnableJpaRepositories
class RepositoryConfiguration {

    /*
    var props: MongoProperties

    @Autowired
    constructor(props: MongoProperties) {
        this.props = props
    }

    fun mongock(context: ApplicationContext): SpringBootMongock {

        val template = MongockTemplate()

        return SpringBootMongockBuilder(context, op)
    }
    */

}
