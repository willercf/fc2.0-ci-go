package br.com.tqi.mozart.services.botstudio.domain.event

import java.time.Instant

class LibraryCreatedEvent(
        val id: String,
        val name: String,
        val createdAt: Instant,
        val updatedAt: Instant
)
