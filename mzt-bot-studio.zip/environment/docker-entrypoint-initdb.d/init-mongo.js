print('Start #################################################################');

db = db.getSiblingDB('bot_studio_local');
db.createUser(
    {
      user: 'bot_studio',
      pwd: 'bot_studio',
      roles: [{ role: 'readWrite', db: 'bot_studio_local' }],
    },
);
db.createCollection('teste');

print('END #################################################################');